/**
 * login block control
 */
function showLoginBlock()
{
    $("#login_Box").css("display", "block");
}

function closeLoginBlock()
{
    $("#login_Box").css("display", "none");
}

function login_Info_Check()
{
    var id = $("#user_id").val();
    var pw = $("#user_pw").val();
    var idType = /^([A-Za-z0-9]){6,15}$/;
    var pwType = /^.*(?=^.{8,15})(?=.*\d)(?=.*[a-zA-Z])(?=.*[!@#$%^&+=]).*$/;

    if($.trim(id) == "" || $.trim(pw) == "" || !idType.test(id) || !pwType.test(pw))
    {
        alert("아이디 또는 패스워드 입력양식을 체크해주세요");
        closeLoginBlock();
        return;
    }
}

function login(accounts)
{
    console.log(accounts);
    let id = $("#user_id").val();
    let pw = $("#user_pw").val();
    let idCheck = false;
    let pwCheck = false;

    for(var i = 0; i < accounts.length/2; i++)
    {
        if(accounts[i] === id)
        {
            idCheck = true;
            alert(accounts[i]);
            alert(accounts[i+1] + "\n" + pw);
            alert(accounts[i+1] === pw);
            if(accounts[i+1] !== pw) break;

            let $user_name = $("<p>" + accounts[i] + "</p>");
            let parent = $("#login_name");
            parent.children().remove();
            parent.append($user_name);
            return;
        }
    }

    if(!idCheck)
    {
        alert("존재하지 않는 회원입니다.");
        return;
    }

    if(!pwCheck)
    {
        alert("비밀번호가 일치하지 않습니다.");
        return;
    }

    alert("hi");
}

$(document).ready(function(){
    $("#join_submit").click(function(){
        $("#login_name").load("./Login/person.txt", function(data, status, xhr){    //data는 데이터 객체, status는 상태 객체, xhr은 XMHttpRequest 객체와 상태코드
            if(status === "success")
            {
                let account = data.split(/\n|\|/g);
                login(account);
            }
            else
            {
                alert("fail! : " + xhr.status + " : " + xhr.statusText);
            }
        });
    });
});